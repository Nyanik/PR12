﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MultiPageApplication.Pages
{
    /// <summary>
    /// Логика взаимодействия для ZakupList.xaml
    /// </summary>
    public partial class ZakupList : Page
    {
        public ZakupList()
        {
            InitializeComponent();
            LVZakup.ItemsSource = BaseClass.Base.Zakup.ToList();
        }

        
        private void TextBlock_Loaded_1(object sender, RoutedEventArgs e)
        {
            TextBlock tb = (TextBlock)sender;
            int index = Convert.ToInt32(tb.Uid);
            List<Postavshik> TC = BaseClass.Base.Postavshik.Where(x => x.ID_Postavshik == index).ToList();
            string str = "";
            foreach (Postavshik item in TC)
            {
                str += item.NamePostavhik;
            }
            tb.Text = str.Substring(0);
        }

        private void TextBlock_Loaded_2(object sender, RoutedEventArgs e)
        {
            TextBlock tb = (TextBlock)sender;
            int index = Convert.ToInt32(tb.Uid);
            List<ZakupKomplect> TC = BaseClass.Base.ZakupKomplect.Where(x => x.ID_Zakup == index).ToList();
            int sum = 0;
            foreach (ZakupKomplect item in TC)
            {
                sum += item.Komplect.Cost * item.Kolvo;
            }
            tb.Text = sum + " рублей";
        }

        private void TextBlock_Loaded(object sender, RoutedEventArgs e)
        {
            TextBlock tb = (TextBlock)sender;
            int index = Convert.ToInt32(tb.Uid);
            List<ZakupKomplect> TC = BaseClass.Base.ZakupKomplect.Where(x => x.ID_Zakup == index).ToList();
            string str = "";
            foreach (ZakupKomplect item in TC)
            {
                str += item.Kolvo;
            }
            tb.Text = "Количество:" + str.Substring(0);
        }

        private void TextBlock_Loaded_3(object sender, RoutedEventArgs e)
        {
            TextBlock tb = (TextBlock)sender;
            int index = Convert.ToInt32(tb.Uid);
            List<Komplect> TC = BaseClass.Base.Komplect.Where(x => x.ID_Komplect == index).ToList();
            string str = "";
            foreach (Komplect item in TC)
            {
                str += item.Kompl;
            }
            tb.Text = "Комплектующее:" + str.Substring(0);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.mainFrame.Navigate(new FirstPage());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FrameClass.mainFrame.Navigate(new FirstPage());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Button B = (Button)sender; 
            int ind = Convert.ToInt32(B.Uid); 
            Zakup ZakDelete = BaseClass.Base.Zakup.FirstOrDefault(y => y.ID_Zakup == ind); 
            BaseClass.Base.Zakup.Remove(ZakDelete);  
            BaseClass.Base.SaveChanges();
            FrameClass.mainFrame.Navigate(new ZakupList()); 
            MessageBox.Show("Запись удалена");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            FrameClass.mainFrame.Navigate(new UpdatePage());
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            FrameClass.mainFrame.Navigate(new UpdatePage());
        }
    }
}

