﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiPageApplication
{
    internal class BaseClass
    {
        public static Entities Base;
    }
}
